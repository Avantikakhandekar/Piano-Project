# piano

Based on tutorial Ania Kubów | Codecademy

Audio Object in JavaScript, HTML, CSS
